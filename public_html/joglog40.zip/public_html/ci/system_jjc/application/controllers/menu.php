<?php
class Menu extends Controller {

function view(){
  $this->load->view('menu2_view');
}
}
?>