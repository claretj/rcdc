<?php
include ("funcs.php");

class Runlog extends Controller {

function __construct() {
  parent::__construct();
  $this->load->database();
}

/*
function index(){
  $this->view_this();
}

function view_this(){
  $monday=time() - (date('N')-1)*86400;
  $data['month_arr']=$this->load_month($monday);
  $data['week_data']=$this->get_week();
  $data['shoe_array']=$this->get_shoes();
  $data['day_data']=$this->load_day(date("Y-m-d"));
  $this->load->view('runlog_view', $data);
}

// used for getting certain day 
function view_date(){
  $date=$_POST['date'];
  $data['month_arr']=$this->load_month($monday);
  $data['week_data']=$this->get_week();
  $data['shoe_array']=$this->get_shoes();
  $data['day_data']=$this->load_day($date);
  $this->load->view('runlog_view', $data);
}
*/

function view(){
  $monday=time() - (date('N')-1)*86400;
  $data['month_arr']=$this->load_month($monday);
  $data['week_data']=$this->get_week();
  $data['shoe_array']=$this->get_shoes();
  $data['day_data']=$this->load_day(date("Y-m-d"));
  $this->load->view('runlog_view', $data);
}

function load_month($start_monday){
 $month_arr=array();
 for ($iWeek=11; $iWeek>=0; $iWeek--){
  $monday=$start_monday- $iWeek*7*86400;
  $week_distance=0;
  for ($i=0; $i<=6; $i++) {
    $this_date=$monday+$i*86400;

    $day_stat = array("day"=>date('Y-m-d',$this_date),
                                "dayMD"=>date('m/d/y',$this_date),
                                "course"=>"",
                                "distanceStr"=>"0",
                                "timeStr"=>"",
                                "paceStr"=>"",
                                "comments"=>"",
                                "is_today"=>date('m/d/y',$this_date)==date('m/d/y')?"Y":"N" );


    $sql="SELECT c.descr course_descr, run.distance, run.time_sec, run.comments ".
        "FROM run, course c ".
        "WHERE run.rundate = '".date('Y-m-d',$this_date)."' ".
        "AND run.course_id = c.id ";
    $query = $this->db->query($sql);
    if ($query->num_rows() > 0){
      $row = $query->row_array(); 
      $distance=$row['distance'];
      if ($distance>0){
        $distanceStr=$distance;
        $week_distance+=$distance;
        $time_sec=$row['time_sec'];
        getTimeStr($time_sec,$timeStr);
        $pace_sec=floor($time_sec/$distance);
        getTimeStr($pace_sec,$paceStr);

        $day_stat['course']=$row['course_descr'];
        $day_stat['distanceStr']=$distanceStr;
        $day_stat['timeStr']=$timeStr;
        $day_stat['paceStr']=$paceStr;
        $day_stat['comments']=$row['comments'];
      }
    }
    $week_arr[$i]=$day_stat;
  }
  $week_stat['monday_str']=date("F d Y",$monday);
  $week_stat['mondayYmd']=date("Y-m-d",$monday);
  $week_stat['week_arr']=$week_arr;
  $week_stat['week_distance']=$week_distance;
  $month_arr[$iWeek]=$week_stat;
 } // end loop over weeks
 //$data['month_arr']=$month_arr;
 return $month_arr;
} // end function view


private function get_shoes(){
  $sql_string="select shoe.descr,round(sum(run.distance)) distance,DATE_FORMAT(max(rundate), '%c/%y') maxdate,DATE_FORMAT(min(rundate), '%c/%y') mindate, max(rundate) ".
  "from shoe, run ".
  "where shoe.id=run.shoe_id ".
  "and shoe.status='A' ".
  "group by shoe.id ".
  "union select shoe.descr,0,'N/A','N/A',null from shoe where id not in (select shoe_id from run)".
  "order by 5 desc ";

  $query = $this->db->query($sql_string);
                 
  return $query->result_array();

}

private function get_week(){
  $monday=time() - (date('N')-1)*86400;

  $week_distance=0;
  for ($i=0; $i<=6; $i++) {
    $this_date=$monday+$i*86400;

    $day_stat = array("day"=>date('Y-m-d',$this_date),
                                "dayMD"=>date('D, M j',$this_date),
                                "course"=>"",
                                "run_type"=>"",
                                "distanceStr"=>"",
                                "timeStr"=>"",
                                "paceStr"=>"",
                                "comments"=>"" );


    $sql="SELECT c.descr course_descr, rt.descr rt_descr, run.distance, run.time_sec, run.comments ".
        "FROM run, course c, run_type rt ".
        "WHERE run.rundate = '".date('Y-m-d',$this_date)."' ".
        "AND run.run_type_id=rt.id ".
        "AND run.course_id = c.id ";
    $query = $this->db->query($sql);
    if ($query->num_rows() > 0){
      $row = $query->row_array(); 
      $distance=$row['distance'];
      if ($distance>0){
        $distanceStr=$distance;
        $week_distance+=$distance;
        $time_sec=$row['time_sec'];
        getTimeStr($time_sec,$timeStr);
        $pace_sec=floor($time_sec/$distance);
        getTimeStr($pace_sec,$paceStr);

        $day_stat['course']=$row['course_descr'];
        $day_stat['run_type']=$row['rt_descr'];
        $day_stat['distanceStr']=$distanceStr;
        $day_stat['timeStr']=$timeStr;
        $day_stat['paceStr']=$paceStr;
        $day_stat['comments']=$row['comments'];
      }
    }
    $week_arr[]=$day_stat;
  }
  $data['monday_str']=date("F d Y",$monday);
  $data['monday_prev_str']=date("Y-m-d",$monday-7*86400);
  $data['monday_next_str']=date("Y-m-d",$monday+7*86400);
  $data['week_arr']=$week_arr;
  $data['week_distance']=$week_distance;
  return $data;
}

private function load_day($date){
  $sql_string="select * from run where rundate='".$date."' ";
  $query = $this->db->query($sql_string);

  if ($query->num_rows() > 0){
    $row = $query->row_array(); 
    $distance=$row['distance'];
    getTimeStr($row['time_sec'],$elapsed_time);
    $course_id=$row['course_id'];
    $comments=$row['comments'];
    $run_type_id=$row['run_type_id'];
    $shoe_id=$row['shoe_id'];
  }else{
    $distance="";
    $elapsed_time="";
    $course_id="";
    $comments="";
    $run_type_id="";
    $shoe_id="";
  }

  YmdToDate($date,$date_date);
  $mdy_str=date("F d Y",$date_date);

  $day_data['date']=$date;                 
  $day_data['date_long']=$mdy_str;
  $day_data['distance']=$distance;
  $day_data['elapsed_time']=$elapsed_time;
  $day_data['course_id']=$course_id;
  $day_data['comments']=$comments;
  $day_data['run_type_id']=$run_type_id;
  $day_data['shoe_id']=$shoe_id;

  $this->get_dropdowns($day_data['course_arr'],$day_data['run_type_arr'],$day_data['shoe_arr'], $shoe_id);
  return $day_data;
}

private function get_dropdowns(&$course_arr,&$run_type_arr,&$shoe_arr,$shoe_id){
  $sql_string="SELECT course.id, course.descr, max( rundate ) ".
  "FROM course, run ".
  "WHERE course.id = run.course_id ".
  "AND course.status = 'A' ".
  "GROUP BY course.id ".
  "ORDER BY 3 DESC ";
  $query = $this->db->query($sql_string);
  $course_arr=$query->result_array();

  $sql_string="SELECT rt.id, rt.descr ".
  "FROM run_type rt ".
  "ORDER BY sort_order asc ";
  $query = $this->db->query($sql_string);
  $run_type_arr=$query->result_array();

  $sql_string="SELECT shoe.id, shoe.descr, max( rundate ) end ".
  "FROM shoe, run ".
  "WHERE shoe.id = run.shoe_id ".
  "AND shoe.status = 'A' ".
  "GROUP BY shoe.id ".
  "union select id,descr,null from shoe where id not in (select shoe_id from run)  and shoe.status='A' ";
  if (!empty($shoe_id)){
  $sql_string=$sql_string." union SELECT shoe.id, shoe.descr, max( rundate ) ".
  " FROM shoe, run ".
  " WHERE shoe.id = ".$shoe_id.
  " AND shoe.status = 'I' ".
  " GROUP BY shoe.id ";
  }
  $sql_string=$sql_string." ORDER BY 3 DESC ";
  $query = $this->db->query($sql_string);
  $shoe_arr=$query->result_array();
}

function post_entry(){
  $date=$_POST['date'];
  $distance=$_POST['distance'];
  $elapsed_time=$_POST['elapsed_time'];

  //delete row with that date
  $this->db->query("delete from run where rundate='".$date."'");

  //insert new row with that date
  if ($distance>0){
    $hours=0;
    if (strlen($elapsed_time)<=2){
      $minutes=$elapsed_time;
      $seconds=0;
    }else{
      $seconds=substr($elapsed_time,-2); //last 2 chars
      $minutes=substr($elapsed_time,-5,2);
      if (strlen($elapsed_time)>=7) $hours=substr($elapsed_time,0,strlen($elapsed_time)-6);
    }
      
    $time_sec=$hours*3600+$minutes*60+$seconds;
    //if ($hours==0){$hours="";}
    //$seconds=str_pad($seconds, 2, "0", STR_PAD_LEFT);
    $course_id=$_POST['course_id'];
    $comments=$_POST['comments'];
    $run_type_id=$_POST['run_type_id'];
    $shoe_id=$_POST['shoe_id'];
    $sql_string="insert into run (rundate,distance,time_sec,course_id,comments,run_type_id,shoe_id) ".
      "values ('".$date."',".$distance.",".$time_sec.",".$course_id.", '". 
      $comments."',".$run_type_id.", ".
      $shoe_id."); ";
    $this->db->query($sql_string);
  }
  $this->view();
}

} //end class Runlog
?>
