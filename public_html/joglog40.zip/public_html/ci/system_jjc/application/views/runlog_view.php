<!doctype html>
<html>
<?php
  //include("header.php");
  $this->load->helper('url');
  $this->load->helper('form');
?>

    <head>
        <meta charset="UTF-8" />
        <title>Julio's Log</title>
        <link rel="stylesheet" href="/ci/ray.css">
        <link rel="stylesheet" href="/ci/apple.css" title="jQTouch">

        <script src="/ci/zepto.min.js" type="text/javascript" charset="utf-8"></script>
        <script src="/ci/jqtouch.min.js" type="text/javascript" charset="utf-8"></script>
        <!-- Uncomment the following two lines (and comment out the previous two) to use jQuery instead of Zepto. -->
        <!-- <script src="../../src/lib/jquery-1.7.min.js" type="application/x-javascript" charset="utf-8"></script> -->
        <!-- <script src="../../src/jqtouch-jquery.min.js" type="application/x-javascript" charset="utf-8"></script> -->

        <script src="/ci/jqt.themeswitcher.min.js" type="application/x-javascript" charset="utf-8"></script>

        <script type="text/javascript" charset="utf-8">
            var jQT = new $.jQTouch({
                icon: 'jqtouch.png',
                icon4: 'jqtouch4.png',
                addGlossToIcon: false,
                startupScreen: 'jqt_startup.png',
                statusBar: 'black-translucent',
                themeSelectionSelector: '#jqt #themes ul',
                preloadImages: []
            });

            // Some sample Javascript functions:
            $(function(){

                // Show a swipe event on swipe test
                $('#swipeme').swipe(function(evt, data) {
                    var details = !data ? '': '<strong>' + data.direction + '/' + data.deltaX +':' + data.deltaY + '</strong>!';
                    $(this).html('You swiped ' + details );
                    $(this).parent().after('<li>swiped!</li>')
                });

                $('#tapme').tap(function(){
                    $(this).parent().after('<li>tapped!</li>')
                });

                $('a[target="_blank"]').bind('click', function() {
                    if (confirm('This link opens in a new window.')) {
                        return true;
                    } else {
                        return false;
                    }
                });

                // Page animation callback events
                $('#pageevents').
                    bind('pageAnimationStart', function(e, info){ 
                        $(this).find('.info').append('Started animating ' + info.direction + '&hellip;  And the link ' +
                            'had this custom data: ' + $(this).data('referrer').data('custom') + '<br>');
                    }).
                    bind('pageAnimationEnd', function(e, info){
                        $(this).find('.info').append('Finished animating ' + info.direction + '.<br><br>');

                    });
                
                // Page animations end with AJAX callback event, example 1 (load remote HTML only first time)
                $('#callback').bind('pageAnimationEnd', function(e, info){
                    // Make sure the data hasn't already been loaded (we'll set 'loaded' to true a couple lines further down)
                    if (!$(this).data('loaded')) {
                        // Append a placeholder in case the remote HTML takes its sweet time making it back
                        // Then, overwrite the "Loading" placeholder text with the remote HTML
                        $(this).append($('<div>Loading</div>').load('ajax.html .info', function() {        
                            // Set the 'loaded' var to true so we know not to reload
                            // the HTML next time the #callback div animation ends
                            $(this).parent().data('loaded', true);  
                        }));
                    }
                });
                // Orientation callback event
                $('#jqt').bind('turn', function(e, data){
                    $('#orient').html('Orientation: ' + data.orientation);
                });
                
            });
        </script>
        <style type="text/css" media="screen">
            #jqt.fullscreen #home .info {
                display: none;
            }
            div#jqt #about {
                padding: 100px 10px 40px;
                text-shadow: rgba(0, 0, 0, 0.3) 0px -1px 0;
                color: #999;
                font-size: 13px;
                text-align: center;
                background: #161618;
            }
            div#jqt #about p {
                margin-bottom: 8px;
            }
            div#jqt #about a {
                color: #fff;
                font-weight: bold;
                text-decoration: none;
            }
        </style>
    </head>
    <body>
        <div id="jqt">
            <div id="about" class="selectable">
                    <!--<p><img src="jqtouch.png" /></p>-->
                    <p><strong>Julio's Run Log</strong><br>Version 1.0 beta<br>
                        <a href="http://www.rayclaret.com">By Julio Claret</a></p>
                    <!--<p><em>Create powerful mobile apps with<br> just HTML, CSS, and jQuery.</em></p>
                    <p>
                        <a target="_blank" href="http://twitter.com/jqtouch">@jQTouch on Twitter</a>
                    </p>-->
                    <p><br><br><a href="#" class="grayButton goback">Close</a></p>
            </div>
            <div id="month">
                <div class="toolbar">
                    <h1>Month</h1>
                    <a class="back" href="#home">Home</a>
                </div>
                <div class="scroll">

<script language="Javascript">
  function runEntry(dateStr) {
    document.MyForm.date.value=dateStr;
    document.MyForm.submit();
  }
</script>

<form name="MyForm" action="<? echo site_url("/runlog/view_date"); ?>" method="post">
<input type="hidden" name="date">
</form>

<!-- with table -->
<table  class="table" width="100%"  cellspacing="0"  >
  <tr>
    <td class="sec row nw" align="left" style="border-right: 1px solid #CFCFCF;">Week</td>
    <td  class="sec row nw" align="right">Mo</td>
    <td  class="sec row nw" align="right">Tu</td>
    <td  class="sec row nw" align="right">We</td>
    <td  class="sec row nw" align="right">Th</td>
    <td  class="sec row nw" align="right">Fr</td>
    <td  class="sec row nw" align="right">Sa</td>
    <td  class="sec row nw" align="right">Su&nbsp;</td>
    <td  class="sec row nw" align="right" style="border-left: 1px solid #CFCFCF;">&Sigma;&nbsp;</td>
  </tr>
<?php
  $iRow=0;
  foreach ($month_arr as $iWeek){
    if ($iRow++ % 2 ==0) {$tdclass="ind nw tL";}else{$tdclass="ind alt tL";}
    $week_arr=$iWeek['week_arr'];
    $week_distance=$iWeek['week_distance'];
?>
  <tr>
    <td class="<? echo $tdclass ?>" align="left" style="border-right: 1px solid #CFCFCF;">
     <? echo $week_arr[0]['dayMD'];?>
    </td>
<?php
  for ($i=0; $i<=6; $i++) {
    $today_style=$week_arr[$i]['is_today']=="Y"?"style='background-color: yellow;color: #780000;text-decoration:none'":"style='text-decoration:none'";
?>
    <td align="right" class="<? echo $tdclass ?>">
    <a href='javascript:runEntry("<? echo $week_arr[$i]['day'] ?>")'  <? echo $today_style; ?>>
      <? echo $week_arr[$i]['distanceStr']>0?round($week_arr[$i]['distanceStr'],1):"&nbsp;&nbsp;&nbsp;"; ?></a>
    </td>
<?php
  } //loop over days
?>
<td align="right" class="<? echo $tdclass ?>" style="border-left: 1px solid #CFCFCF;"><? echo floor($week_distance); ?>&nbsp;</td>
</tr>
<?php
  } //loop over weeks
?>
</table>

                </div>
            </div> // end div month

            <div id="week">
                <div class="toolbar">
                    <h1>Week</h1>
                    <a class="back" href="#">Home</a>
                </div>
                <div class="scroll">

<?php
  $monday_str=$week_data['monday_str'];
  $monday_prev_str=$week_data['monday_prev_str'];
  $monday_next_str=$week_data['monday_next_str'];
  $week_arr=$week_data['week_arr'];
  $week_distance=$week_data['week_distance'];
?>

<script language="Javascript">
  function runEntry(dateStr) {
    document.MyForm.date.value=dateStr;
    document.MyForm.submit();
  }
  function getCal(dateStr) {
    document.NavForm.monday.value=dateStr;
    document.NavForm.submit();
  }
</script>

<div mode="nowrap"  class="sec row" style="white-space: nowrap;"  >
<a  class="white" id="Cal" >
  <a href='javascript:getCal("<? echo $monday_prev_str ?>")'>&lt;</a>
  Week of <?php echo $monday_str; ?>
  <a href='javascript:getCal("<? echo $monday_next_str ?>")'>&gt;</a>
</a>
</div>


<form name="MyForm" action="<? echo site_url("/run_entry/view_date"); ?>" method="post">
<input type="hidden" name="date">
</form>

<form name="NavForm" action="<? echo site_url("/calendar_week/view_date"); ?>" method="post">
<input type="hidden" name="monday">
</form>

<?php
  for ($i=0; $i<=6; $i++) {
    if ($i % 2 ==0){
      echo '<div class="ind" style="white-space: nowrap;"  >';
    }else{
      echo '<div class="ind alt" style="white-space: nowrap;"  >';
    }
?>
    <a href='javascript:runEntry("<? echo $week_arr[$i]['day'] ?>")' >[<? echo $week_arr[$i]['dayMD'] ?>]</a>&nbsp;&nbsp;<? echo $week_arr[$i]['distanceStr']>0?$week_arr[$i]['course'].":&nbsp;".$week_arr[$i]['run_type']:"" ?><br>
          <? echo $week_arr[$i]['distanceStr']>0?$week_arr[$i]['distanceStr']." miles @ ".$week_arr[$i]['paceStr']." min/mile = ".$week_arr[$i]['timeStr']:"" ?><br>
          <? echo $week_arr[$i]['distanceStr']>0?$week_arr[$i]['comments']:"" ?>
  </div>
<?php
  }
  ?>
<hr>Total: <? echo $week_distance ?>&nbsp;miles



                </div>
            </div> // end div week

            <div id="animations2">
                <div class="toolbar">
                    <h1>Animations</h1>
                    <a href="#" class="back">Animations</a>
                </div>
                <div class="scroll">
                    <ul class="rounded">
                    </ul>
                </div>
            </div>
            <div id="animdemo">
                <div style="font-size: 1.5em; text-align: center; margin: 160px 0 90px; font-family: Marker felt;">
                    Pretty smooth, eh?            
                </div>
                <a style="margin-bottom: 120px;color:rgba(0,0,0,.9)" href="#" class="whiteButton goback">Go back</a>
            </div>
            <div id="buttons">
                <div class="toolbar">
                    <h1>Buttons!</h1>
                    <a href="#" class="back">Home</a>
                </div>
                <div style="margin-top: 10px;" class="scroll">
                    <a href="#" class="whiteButton">White</a>
                    <br>
                    <a href="#" class="grayButton">Gray</a>
                    <br>
                    <a href="#" class="redButton">Red</a>
                    <br>
                    <a href="#" class="greenButton">Green</a>
                </div>
            </div>

            <div id="shoes">
                <div class="toolbar">
                    <h1>Shoes</h1>
                    <a class="back" href="#home">Home</a>
                </div>
                <div class="scroll">

<table  class="table" width="100%"  cellspacing="0">
  <tr>
    <td  class="sec row nw" width="5%">&nbsp;</td>
    <td  class="sec row nw" width="65%">Shoe</td>
    <td  class="sec row nw" width="10%" align="right">Miles</td>
    <td  class="sec row nw" width="10%" align="right">From</td>
    <td  class="sec row nw" width="10%" align="right">To&nbsp;</td>
  </tr>
<?php
  $iRow=0;
  foreach ($shoe_array as $row){
    if ($iRow % 2 ==0) {$tdclass="ind nw tL";}else{$tdclass="ind alt tL";}
    if ($row['distance']>450){
      $color='red';
    }else if ($row['distance']>350){
      $color='yellow';
    }else{
      $color='#00FF00';
    }
?>
  <tr>
    <td class="<? echo $tdclass; ?>"  style="background:<? echo $color; ?>">&nbsp;</td>
    <td class="<? echo $tdclass; ?>"><? echo $row['descr'] ;?></td>
    <td class="<? echo $tdclass; ?>" align="right"><? echo $row['distance'];?></td>
    <td class="<? echo $tdclass; ?>" align="right"><? echo $row['mindate'];?></td>
    <td class="<? echo $tdclass; ?>" align="right"><? echo $row['maxdate'];?>&nbsp;</td>
  </tr>
<?php
    $iRow++;
  }		
?>
</table>

                </div>
            </div>
            <div id="today">

<?php
  $date=$day_data['date'];                 
  $mdy_str=$day_data['date_long'];
  $distance=$day_data['distance'];
  $elapsed_time=$day_data['elapsed_time'];
  $course_id=$day_data['course_id'];
  $comments=$day_data['comments'];
  $run_type_id=$day_data['run_type_id'];
  $shoe_id=$day_data['shoe_id'];
  $course_arr=$day_data['course_arr'];
  $run_type_arr=$day_data['run_type_arr'];
  $shoe_arr=$day_data['shoe_arr'];

?>

                <div class="toolbar">
                    <h1>Run Entry</h1>
                    <a href="#" class="back">Home</a>
                </div>
                <form action=<? echo site_url("/runlog/post_entry"); ?> method="post" class="form">
                    <input type="hidden" name="date" value="<? echo($date); ?>" />
                    <ul class="edit rounded">
                        <li class="arrow">
<?php
foreach($course_arr as $row)  {
  $options[$row['id']]=$row['descr'];
}
echo form_dropdown('course_id', $options, $course_id);
?>
                        </li>
                        <li class="arrow">
<?php
$options=array();
foreach($run_type_arr as $row)  {
  $options[$row['id']]=$row['descr'];
}
echo form_dropdown('run_type_id', $options, $run_type_id);
?>
                        </li>
                        <li class="arrow">
<?php
$options=array();
foreach($shoe_arr as $row)  {
  $options[$row['id']]=$row['descr'];
}
echo form_dropdown('shoe_id', $options, $shoe_id);
?>
                        </li>
                        <li><input type="number" name="distance" placeholder="Miles" value='<? echo $distance ?>' /></li>                    
                        <li><input type="text" name="elapsed_time" placeholder="H:MM:SS or MM" value='<? echo $elapsed_time; ?>' /></li>                    
                        <li><input type="password" name="some_name" id="some_name" placeholder="Password" /></li>
                        <li><textarea rows="2" placeholder="Comments" ><? echo $comments ?></textarea></li>
                    </ul>
                   <!-- <a style="margin-top: 10px; margin-bottom: 10px; color:rgba(0,0,0,.9)" href="#" class="submit whiteButton">Submit</a>-->
                    <input type='submit' value='Enter'>
                </form>
            </div>
            <div id="home" class="current">
                <div class="toolbar">
                    <h1>Julio's Log</h1>
                    <a class="button slideup" id="infoButton" href="#about">About</a>
                </div>
                <div class="scroll">
                    <ul class="rounded">
                        <li class="arrow"><a href="#today">Today</a> </li>
                        <li class="arrow"><a href="#week">Week <small><? echo $week_distance ?>&nbsp;miles</small></a></li>
                        <li class="arrow"><a href="#month">Month</a></li>
                        <li class="arrow"><a href="#shoes">Shoes</a></li>
                    </ul>
                    <div class="info">
                        <p>Put some info here.</p>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>