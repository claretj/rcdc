<html>
<head>
<?php
  include("header.php");
  $this->load->helper('url');
  $this->load->helper('form');
?>
   <title>Run Entry</title>
</head>

<html>
<body>

<div id="header">
<h1><a>Run Entry</a></h1>
</div>


<div mode="nowrap"  class="sec row" style="white-space: nowrap;"  >
  <a  class="white" id="Run Entry" >
    Run Entry for <? echo($date_long) ?>
  </a>
</div>

<form action=<? echo site_url("/run_entry/post_entry"); ?> method=post>
<? echo form_hidden('date', $date); ?>
  Course:
<?php
foreach($course_arr as $row)  {
  $options[$row['id']]=$row['descr'];
}
echo form_dropdown('course_id', $options, $course_id);
?>

  <br>Run Type: 
<?php
$options=array();
foreach($run_type_arr as $row)  {
  $options[$row['id']]=$row['descr'];
}
echo form_dropdown('run_type_id', $options, $run_type_id);
?>
  <br>Shoe: 
<?php
$options=array();
foreach($shoe_arr as $row)  {
  $options[$row['id']]=$row['descr'];
}
echo form_dropdown('shoe_id', $options, $shoe_id);
?>
  <br>Distance: <input type='text' name='distance' maxlength='6' size='4' value='<? echo $distance ?>'> miles
  <br>Time: <input type='input' maxlength='1' size='1' name='hours' value='<? echo $hours ?>'>:
            <input type='input' maxlength='2' size='3' name='minutes' value='<? echo $minutes ?>'>:
				<input type='input' maxlength='2' size='3' name='seconds' value='<? echo $seconds ?>'>
  <table border='0' cellspacing='0'>
  <tr>
  <td valign='top'>Comments: </td>
  <td><textarea name='comments' rows='1'><? echo $comments ?></textarea></td>
  </tr>
  </table>
<input type='submit' value='Enter'>
</form>

</div>
</body>
</html>