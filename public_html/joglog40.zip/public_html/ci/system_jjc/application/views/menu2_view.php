<html>
<head>
<?php include("header.php"); ?>
<title>Julio's Log</title>
</head>
<body>
<div id="jqt">

            <div id="home" class="current">
                <div class="toolbar">
                    <h1>Julio's Log</h1>
<!--                    <a class="button slideup" id="infoButton" href="#about">About</a> -->
                </div>

<div class="scroll">
<ul class="rounded">
<li class="forward"><a href="/ci/index.php/run_entry/view_today">Today</a></li>
<li class="arrow"><a href="/ci/index.php/calendar_week/view_this">This Week</a></li>
<li class="arrow"><a href="/ci/index.php/calendar_month/view_this">This Month</a></li>
<li class="arrow"><a href="/ci/index.php/shoe/view">My Shoes</a></li>
</ul>
</div>
<!--<div id="content">
<h2>About</h2>
<p>Julio is a runner living in John's Creek with his wife and 3 kids.</p>
</div>-->
</div>
</body>
</html>