						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="clr"></div>
	</div>
	</div>
	</div>
	<div class="footer_con">
		<div class="footer">
			&copy;2015 rayclaret.com All Rights Reserved<br /> <a
				href="http://www.rayclaret.com/terms/">Terms &amp; Conditions</a>
		</div>

</body>
</html>