<?php
class Menu extends CI_Controller {

function view(){
  $this->load->view('menu2_view');
}
}
?>