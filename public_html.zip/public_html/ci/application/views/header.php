<?php
  header("Cache-Control: no-cache, must-revalidate");
  $this->load->helper('url');
?>
<script type="text/javascript" src="../../jquery.js"></script>
<script type="text/javascript" src="../../iphone.js"></script>
<meta name="viewport" content="user-scalable=no, width=device-width" />
<!--
<link rel="stylesheet" type="text/css" href="/ci/ray.css" media="only screen and (max-width: 480px)" />
<link rel="stylesheet" type="text/css" href="/ci/iphone.css" media="only screen and (max-width: 480px)" />

<link rel="stylesheet" type="text/css" href="/ci/apple.css" media="only screen and (max-width: 480px)" />
<link rel="stylesheet" type="text/css" href="/ci/ray.css" media="screen and (min-width: 481px)" />  
-->
<title>Julio's Log</title>

<link rel="stylesheet" type="text/css" href="../../ray.css" media="all" />

