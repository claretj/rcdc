// Created by iWeb 2.0.4 local-build-20090529

setTransparentGifURL('../Media/transparent.gif');function hostedOnDM()
{return false;}
function onPageLoad()
{loadMozillaCSS('Archive_files/ArchiveMoz.css')
adjustLineHeightIfTooBig('id1');adjustFontSizeIfTooBig('id1');detectBrowser();Widget.onload();fixAllIEPNGs('../Media/transparent.gif');fixupIECSS3Opacity('id2');performPostEffectsFixups()}
function onPageUnload()
{Widget.onunload();}
