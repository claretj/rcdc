<?php header("Cache-Control: no-cache, must-revalidate"); ?>
<a href='calendar.php'>Calendar</a> - <a href='run_entry.php'>Run Entry</a> - <a href='active_shoes.php'>Shoes</a>