<?php
include ("includes/top.php");
?>
<div id="post-63" class="post-63 page type-page status-publish hentry">
	<h2 class="entry-title">The Adventures of Dave</h2>
	<div class="entry-content">

<h4>Chapter One: Stealing</h4>

Once there was a boy called Dave. Dave was a nice boy and lived in a small village until one day he lost $80. He only had $90 but left with $10.He found out his sister Amy stole $20. His brother Brian stole $20.
And both of his parents stole $20 each. He was very mad so mad he left the village with all of his stuff. He walked and rode his bike to his grandma’s house. When he got there he told her all about it. She got very scared and gave him a helmet of specials. Her friend wore it for war it was the civil war. Dave wore it at the age of 15.

<h4>Chapter Two: Civil War</h4>

Once there was a Chinese woman age of 20. She was a warrior. Her name was Kiky she was unusual. Her favorite thing to do is fight. One day she fought her sister. They fought till a volcano shot out lava and that’s when lava people came. It was lava vs human. And one lava man had a bow and shot them down. Kiky was the only one left. All she had was a water bucket. She found a lake and got some water and it all turned into stone.

<h4>Chapter Three: Abilities</h4>

Dave’s helmet was helpful. It saved his life 89 times he wanted it to be better. One day he visited  Albert Einstein. Dave asked if he could make it better. Dave asked for speed lasers and healing which included black clothes. He was so powerful he could kill 8000002389 normal citizens in a week! One day he ran up Mount Kilimanjaro to test and upgrade his powers. After that he was stronger than a giant.

<h4>Chapter Four: Dave2</h4>

One day Dave went to steal a cake. When he got there it was night. He saw a shadow until some lights went on. Out of a door he saw a Meerkat called Mromro Dave grabbed her by the neck and he was about to shoot lasers that is why his eyes were red. Which made
Mromro run into a cage. Finally he shot a laser and it hit her and she sadly died. Dave didn’t have to sleep because he was never tired he stole a cake and turned off the lights. When he got out he saw it was midnight. In the morning when he woke up he went out the door he saw a man called Dave2. In the afternoon he went and saw Dave2 again after a couple minutes they became good buddies but both bad people.


<h4>Chapter Five: Deadline></h4>      

One day Dave2 went for a walk. He decided to be a good guy. The mayor was making a lie machine. To tell him if people are lying or not. Dave was going there too. When they got there they told him about it and they were telling the truth. And they became good. One day the mayor was killed. Dave already was there. Dave saw a blood stain. He knew that only a girl would kill him. He found a secret fingerprint he put a paper on it. It read Scarlet. Dave knew Scarlet. And in a couple minutes she appeared. He shot lasers at Scarlet. Scarlet had 18 of her. He already shot 5 of them. Scarlet also shot lasers. He shot 11…....  more. He ran around in circles. They both got dizzy and they both fell down. And he shot them both down.  

<h4>Chapter Six: The Time Machine></h4>
The time machine was shipped from mars. It was shipped by 1856. Dave had the time machine in his hands and started to build it. He decided to make it turn into when the pilgrims were there. And there he went there were fights and not much food. It looked like a desert with canons and bombs. And then he saw some pilgrims on a hill and on another the Indians. Dave ran up the Indians hill and said don’t fight just dodge or block. And the Indians did he told the pilgrims the same. And then one Indian and pilgrim looked up and smiled at each other and they told everyone to come out it was safe. They celebrated thanksgiving and at the end they all said thank you to Dave and declared him master.

<h4>Chapter Seven: The New Presidents</h4>
Dave also wanted to go to when the first president wasn’t a president yet. Dave2 went with Dave. They were by the revolutionary war Americans and Germans were there and fighting. 
There was a big tornado coming from the east. When it came, Dave healed so it wouldn’t hurt. Dave2 did his give-away-power to give away Dave’s healing to the Americans. Half of the Germans died and the rest got hurt a little. But all of the weapons broke except the Germans’ huge sword! The Americans used their hands to punch the ones that didn’t have a weapon. Dave2 used his freeze-power to stop the sword from slicing Dave. Dave shot a laser which knocked it out of his hands. Dave2 tried to grab it but the German picked it up and almost sliced Dave2 in half. But Dave’s new power laser sword blocked it. When they were sword fighting Dave2 helped the Americans by teleporting and shooting bullets. Once the Germans without weapons died, Dave2 teleported above the German and he fell down. Then Dave sliced the German. And the Americans called them the first two presidents!

<h4>Chapter Eight: The oldest man ever!</h4>
An old and young machine made Dave 10000 years old! And Dave2 -345! Dave was a giant Dave2 was an ant. One day Dave went to when the dinosaurs were alive to test if his powers were working. Dave2 went to fight a bumblebee. Once they both finished they patrolled and robbed the city. They got stuck in jail for 20 years. But they just busted out of jail and then they went and made a rocket and blasted off to a new planet called ambrosia. And Dave was to big that he shrunk to normal size and Dave2 did the same. There they found lots and lots of giants and insects and bugs. They fought and fought and they finally died.

<h4>Chapter Nine: The mystery person who gives machines out</h4>
The never lasting sword is what Dave used to fight the biggest sword he had ever seen. One day he went to the world war two and used it when he got there he saw the Germans again with the Americans. Dave took out his sword and sliced one down. The Germans backed up then Dave threw it at somebody that person dodged and it hit a lot of people behind him when it came back to Dave it hit him and the Germans ran away. Dave wanted to find out who it was then he saw a American and said did you build this and he said yes.

<h4>Chapter Ten: These things never stop</h4>

One day a tornado an earthquake and a volcano all happened at once.  Dave went outside and saw the earthquake is cracking the earth. The volcano was burning houses. And the tornado broke houses. Dave2 went to get his water bucket. They both lived by an ocean. Dave2 went to get water. After that he poured and poured it on lava. After the volcano was gone Dave gave him healing. Dave2 did his tornado freeze on the tornado. When it freezed Dave shot a laser and it burned the tornado. When the earthquake came Dave2 used his clean ground power. It destroyed the earthquake.

<h4>Chapter Eleven: The human body</h4>

One day Dave and Dave2 shrunk into a human body. Dave was by the brain. Dave2 was by the heart. Dave had been lounging in the brain and they were in Leonardo da Vinci. So Dave could be a smarty. Dave2 got chased by cells. Dave went to the stomach he shook and shook until he saw a baby. The baby got out of the tummy. Dave climbed out and the baby saw him and chased him. The baby was huge. Dave shot a laser it curved and hit the baby and it sadly died. Dave2 came out and they both turned normal again.

	</div>
</div>

<?php
include ("includes/bottom.php");
?>