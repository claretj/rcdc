<html>
	<p>Welcome to my own web page.</p>
	<h2>My solution to 8 queens puzzle</h2>
	Matches solution #11 from
	<a href="https://en.wikipedia.org/wiki/Eight_queens_puzzle">here</a>.
	Read all about it and try it yourself!
	<br>
	
	<br>
	<img src="images/8queens.png" />
	<br />
	<h2>Monster knight.</h2>
	Can you capture all the pawns with the knight?
	<br>
	
	<br>
	<img src="images/monster_knight.jpg" />
</html>