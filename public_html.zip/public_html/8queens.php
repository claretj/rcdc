<?php
include ("includes/top.php");
?>
<div id="post-63" class="post-63 page type-page status-publish hentry">
	<h2 class="entry-title">8 queens puzzle</h2>
	<div class="entry-content">

		<h3>My solution to 8 queens puzzle</h3>
		Matches solution #11 from <a
			href="https://en.wikipedia.org/wiki/Eight_queens_puzzle">here</a>.
		Read all about it and try it yourself! <br> <br> <img
			src="images/8queens.png" /> <br />


	</div>
</div>

<?php
include ("includes/bottom.php");
?>
								